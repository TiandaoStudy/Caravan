/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * Copyright 2009, Flesk Telecom                                               *
 * This file is part of Flesk.NET Software.                                    *
 *                                                                             *
 * Flesk.NET Software is free software: you can redistribute it and/or modify  *
 * it under the terms of the GNU Lesser General Public License as published by *
 * the Free Software Foundation, either version 3 of the License, or           *
 * (at your option) any later version.                                         *
 *                                                                             *
 * Flesk.NET Software is distributed in the hope that it will be useful,       *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of              *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the               *
 * GNU General Public License for more details.                                *
 *                                                                             *
 * You should have received a copy of the GNU Lesser General Public License    *
 * along with Flesk.NET Software. If not, see <http://www.gnu.org/licenses/>.  *
 *                                                                             *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Configuration;
using System.IO;
using System.Net;
using System.Text.RegularExpressions;
using System.Web;

using Flesk.Accelerator.HtmlRewriting;
using Flesk.Accelerator.HttpCompression;

namespace Flesk.Accelerator
{
	/// <summary>
	/// Attaches the functionality of HttpCompression and HtmlRewriting modules to
	/// each Http request.
	/// </summary>
	public sealed class Module : IHttpModule
	{
		Flesk.Accelerator.HttpCompression.ModuleSettings httpSettings = null;
		Flesk.Accelerator.HtmlRewriting.ModuleSettings htmlSettings = null;
		Regex[] rxUserAgent;
		Regex[] rxTextTypes;
		Regex[] rxRequestPath;

		#region System.Web.IHttpModule members

		/// <summary>
		/// Implementation of <see cref="System.Web.IHttpModule"/> Init method.
		/// </summary>
		void IHttpModule.Init(HttpApplication app)
		{
			this.httpSettings = Flesk.Accelerator.HttpCompression.ModuleSettings.GetSettings();
			this.htmlSettings = Flesk.Accelerator.HtmlRewriting.ModuleSettings.GetSettings();

			this.rxUserAgent = CreateRegexList(this.httpSettings.ExcludeUserAgents);
			this.rxTextTypes = CreateRegexList(this.httpSettings.TextContentTypes);
			this.rxRequestPath = CreateRegexList(httpSettings.ExcludeRequestPath);

			app.PostRequestHandlerExecute += new EventHandler(this.Handle_HttpApplication_ProcessRequest);
		}

		/// <summary>
		/// Disposes this instance.
		/// </summary>
		void IHttpModule.Dispose() 
		{
		}


		#endregion

		void Handle_HttpApplication_ProcessRequest(object sender, EventArgs e) 
		{
			HttpApplication app = (HttpApplication)sender;
			this.ProcessResponse(app.Context);
		}

		void ProcessResponse(System.Web.HttpContext ctx)
		{
			if (ctx.Response.SuppressContent)
				return;

			bool skipProcessing = this.MatchRequestPath(ctx);
			if (skipProcessing)
				return;

			skipProcessing = this.MatchUserAgent(ctx);
			if (skipProcessing)
				return;

			skipProcessing = this.IsBinaryResponse(ctx);
			if (skipProcessing)
				return;


			Stream filter = ctx.Response.Filter;
			
			HttpContentEncoding enc = GetEncodingByRequest(ctx);
			if (!ctx.Response.SuppressContent)
			{
				if (enc != null)
				{
					filter = enc;
					ctx.Response.AppendHeader("Content-Encoding", enc.Name);
				}

				if (this.htmlSettings.TagNormalization != CaseNormalization.None)
					filter = new NormalizingFilter(filter, this.htmlSettings.TagNormalization);

				if (this.htmlSettings.EnableWhitespaceFilter)
					filter = new WhitespaceFilter(filter, this.htmlSettings.WhitespaceCollapseMode);
			}

			if (!Object.ReferenceEquals(ctx.Response.Filter, filter))
			{
				ctx.Response.Filter = filter;
				ctx.Response.AppendHeader("X-Powered-By", "Flesk.NET Accelerator");
			}

		}

		HttpContentEncoding GetEncodingByRequest(System.Web.HttpContext ctx) 
		{
			string acceptEncoding = ctx.Request.Headers["Accept-Encoding"];
			if (acceptEncoding != null)
			{
				// determine preferred encoding based on header content
				ContentEncodingInfoParser parser = new ContentEncodingInfoParser(acceptEncoding);
				ContentEncodingInfo prefEncoding = parser.FindByType(this.httpSettings.PreferredAlgorithm);

				foreach (ContentEncodingInfo encodingInfo in parser)
				{
					if (encodingInfo.Preference == 0F)
						continue;

					CompressionTypes method = encodingInfo.CompressionType;

					switch (method)
					{
						case CompressionTypes.Any:
						case CompressionTypes.Compress: // Compress shouldn't be here?
							// use server preference
							if (prefEncoding  != null && prefEncoding.Preference == 0F)
								continue; // foreach

							method = this.httpSettings.PreferredAlgorithm;
							break; // falling through the next case could be useful...
					}
					
					if (
						method == CompressionTypes.GZip &&
						prefEncoding != null &&
						prefEncoding.CompressionType == CompressionTypes.Deflate
						)
						method = CompressionTypes.Deflate;

					switch (method) // ...again
					{
						case CompressionTypes.Deflate:
							return new DeflateEncoding(ctx.Response.Filter, this.httpSettings.CompressionLevel);

						case CompressionTypes.GZip:
							return new GZipEncoding(ctx.Response.Filter);

						case CompressionTypes.Identity:
							// Do nothing. In fact, this is necessary to avoid sending the Content-Encoding header.
							return null;
					}

				} // end foreach

#if WTF
				ctx.Response.StatusCode = Convert.ToInt32(HttpStatusCode.NotAcceptable);
				ctx.Response.SuppressContent = true;
#endif
			}

			return null;
		}

		bool MatchUserAgent(System.Web.HttpContext ctx)
		{
			bool ret = false;

			if (this.rxUserAgent != null && this.rxUserAgent.Length > 0)
			{
				const string objKey = "FxNET:CompressorModule:UAExcludeCache";

				string userAgent = ctx.Request.UserAgent;
				if (userAgent != null && userAgent.Length > 0)
				{
					ret = this.HasMatch(ctx, userAgent, this.rxUserAgent, objKey);
				}
				else
				{
					ret = this.httpSettings.RequireUserAgent;
				}
			}

			return ret;
		}

		bool MatchRequestPath(System.Web.HttpContext ctx)
		{
			bool ret = false;

			if (this.rxRequestPath != null && this.rxRequestPath.Length > 0)
			{
				const string objKey = "FxNET:CompressorModule:RequestPathCache";

				string requestPath = ctx.Request.Path;
				if (requestPath != null && requestPath.Length > 0)
				{
					ret = this.HasMatch(ctx, requestPath, this.rxRequestPath, objKey);
				}

			}

			return ret;
		}

		bool IsBinaryResponse(System.Web.HttpContext ctx)
		{
			bool ret = true;

			string[] responseTypes = ctx.Response.ContentType.Split(';');
			if (responseTypes.Length > 0)
			{
				const string objKey = "FxNET:CompressorModule:ContentTypeCache";
				string contentType = responseTypes[0];
				ret = false;

				if (this.httpSettings.ExcludeContentTypes.Contains(contentType))
				{
					ret = true;
				}

				if (this.httpSettings.TextContentTypes.Count > 0)
				{
					ret = !this.HasMatch(ctx, contentType, this.rxTextTypes, objKey);
				}

			}

			return ret;
		}

		Regex[] CreateRegexList(StringCollection regexStringList)
		{
			Regex[] ret = null;
			if (regexStringList != null && regexStringList.Count > 0)
			{
				List<Regex> rxList = new List<Regex>();
				foreach (string regexString in regexStringList)
				{
					try
					{
						Regex rx = new Regex(regexString);
						rxList.Add(rx);
					}
					catch
					{
						throw new FormatException("The regular expression string in malformed");
					}
				}

				ret = rxList.ToArray();
			}
			return ret;
		}

		bool HasMatch(HttpContext ctx, string @value, Regex[] matches, string objKey)
		{
			bool ret = false;

			Dictionary<int, bool> uaCache = null;
			if (ctx.Application[objKey] == null)
			{
				uaCache = new Dictionary<int, bool>();
				ctx.Application[objKey] = uaCache;
			}
			else
			{
				uaCache = (Dictionary<int, bool>)ctx.Application[objKey];
			}

			int key = @value.GetHashCode();
			if (!uaCache.ContainsKey(key))
			{
				foreach (Regex rx in matches)
				{
					if (rx.IsMatch(@value))
					{
						ret = true;
						break;
					}
				}
				uaCache[key] = ret;
			}
			else
			{
				ret = uaCache[key];
			}

			return ret;
		}


	}


	/// <summary>
	/// Helper class, don't ask
	/// </summary>
	internal class ContentEncodingInfoParser : Comparer<ContentEncodingInfo>, IEnumerable<ContentEncodingInfo>
	{
		string acceptEncoding;
		List<ContentEncodingInfo> requestEncoding = new List<ContentEncodingInfo>();

		public ContentEncodingInfoParser(string acceptEncoding)
		{
			this.acceptEncoding = acceptEncoding;

			TokenParser parser = new TokenParser();
			parser.Tokenizer = new Tokenizer(acceptEncoding);
			parser.Evaluate += new Predicate<Token>(this.Evaluate_AcceptEncoding);
			parser.Parse();

			// sort resulting list by ascending qvalue
			this.requestEncoding.Sort(this);
		}

		bool Evaluate_AcceptEncoding(Token t)
		{
			ContentEncodingInfo enc = new ContentEncodingInfo();
			enc.Name = t.Name;
			enc.ParseQValue(t.Value);

			try
			{
				if (enc.Name == "*")
					enc.CompressionType = CompressionTypes.Any;
				else
					enc.CompressionType = (CompressionTypes)Enum.Parse(typeof(CompressionTypes), enc.Name, true);
			}
			catch
			{
				enc.CompressionType = CompressionTypes.Other;
			}

			this.requestEncoding.Add(enc);
			// keep calling this method
			return false;
		}


		System.Collections.IEnumerator System.Collections.IEnumerable.GetEnumerator()
		{
			return this.GetEnumerator();
		}

		public IEnumerator<ContentEncodingInfo> GetEnumerator()
		{
			// since the encoding list was sorted by ascending qvalue,
			// we'll make it easier for the caller, by returning the values
			// from the end up.
			int index = this.requestEncoding.Count;
			while (--index >= 0)
			{
				yield return this.requestEncoding[index];
			}
		}

		public ContentEncodingInfo FindByType(CompressionTypes type)
		{
			return this.requestEncoding.Find(
					delegate(ContentEncodingInfo enc)
					{
						if (enc.CompressionType == type)
							return true;
						return false;
					}
				);
		}

		public override int Compare(ContentEncodingInfo x, ContentEncodingInfo y)
		{
			if (x == null && y == null)
				return 0;

			if (x != null && y != null)
				return x.Preference.CompareTo(y.Preference);

			if (x != null)
				return 1;

			return -1;
		}
	}


}
