/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * Copyright 2009, Flesk Telecom                                               *
 * This file is part of Flesk.NET Software.                                    *
 *                                                                             *
 * Flesk.NET Software is free software: you can redistribute it and/or modify  *
 * it under the terms of the GNU Lesser General Public License as published by *
 * the Free Software Foundation, either version 3 of the License, or           *
 * (at your option) any later version.                                         *
 *                                                                             *
 * Flesk.NET Software is distributed in the hope that it will be useful,       *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of              *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the               *
 * GNU General Public License for more details.                                *
 *                                                                             *
 * You should have received a copy of the GNU Lesser General Public License    *
 * along with Flesk.NET Software. If not, see <http://www.gnu.org/licenses/>.  *
 *                                                                             *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

using System;
using System.IO;

namespace Flesk.Accelerator.HttpCompression
{

	/// <summary>
	/// Provides basic functionality for an <see cref="System.Web.HttpResponse"/> stream filter.
	/// </summary>
	public abstract class HttpContentEncoding : Stream
	{
		private Stream baseStream;
		private CompressionLevels compressionLevel;


		/// <summary>
		/// Creates a new <see cref="HttpContentEncoding"/> instance.
		/// </summary>
		/// <param name="baseStream">Base stream.</param>
		/// <param name="compressionLevel">Compression level.</param>
		protected HttpContentEncoding(Stream baseStream, CompressionLevels compressionLevel)
		{
			this.baseStream = baseStream;
			this.compressionLevel = compressionLevel;
		}


		/// <summary>
		/// Gets the name of the Http content encoding. The value will
		/// be written to the "Content-encoding" Http header.
		/// </summary>
		public abstract string Name { get; }

		/// <summary>
		/// Gets the compression level.
		/// </summary>
		/// <value></value>
		protected CompressionLevels CompressionLevel 
		{
			get { return this.compressionLevel; }
		}


		protected Stream BaseStream 
		{
			get{ return this.baseStream; }
		}

		public override bool CanRead 
		{
			get { return false; }
		}

		public override bool CanSeek 
		{
			get { return false; }
		}

		public override bool CanWrite 
		{
			get { return this.baseStream.CanWrite; }
		}

		public override long Length 
		{
			get { throw new NotSupportedException(); }
		}

		public override long Position 
		{
			get { throw new NotSupportedException(); }
			set { throw new NotSupportedException(); }
		}

		public override void SetLength(long length) 
		{
			throw new NotSupportedException();
		}

		public override long Seek(long offset, System.IO.SeekOrigin direction) 
		{
			throw new NotSupportedException();
		}

		public override void Close() 
		{
			this.baseStream.Close();
		}

		public override void Flush() 
		{
			this.baseStream.Flush();
		}

		public override int Read(byte[] buffer, int offset, int count) 
		{
			throw new NotSupportedException();
		}

	}
}
