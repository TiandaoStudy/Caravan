/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * Copyright 2009, Flesk Telecom                                               *
 * This file is part of Flesk.NET Software.                                    *
 *                                                                             *
 * Flesk.NET Software is free software: you can redistribute it and/or modify  *
 * it under the terms of the GNU Lesser General Public License as published by *
 * the Free Software Foundation, either version 3 of the License, or           *
 * (at your option) any later version.                                         *
 *                                                                             *
 * Flesk.NET Software is distributed in the hope that it will be useful,       *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of              *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the               *
 * GNU General Public License for more details.                                *
 *                                                                             *
 * You should have received a copy of the GNU Lesser General Public License    *
 * along with Flesk.NET Software. If not, see <http://www.gnu.org/licenses/>.  *
 *                                                                             *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

using System;
using System.Collections;
using System.Collections.Specialized;
using System.Configuration;
using System.Globalization;
using System.Xml;

namespace Flesk.Accelerator.HttpCompression
{
	/// <summary>
	/// Represents the configuration details of the HttpCompression module for the current application.
	/// </summary>
	internal class ModuleSettings
	{
		private CompressionTypes _preferredAlgorithm;
		private CompressionLevels _compressionLevel;
		private StringCollection _excludeContentTypes;
		private StringCollection _excludeUserAgents;
		private StringCollection _textContentTypes;
		private StringCollection _excludeRequestPath;

		private bool _requireUserAgent;


		/// <summary>
		/// The preferred algorithm to use for compression
		/// </summary>
		public CompressionTypes PreferredAlgorithm
		{
			get { return _preferredAlgorithm; }
			set { this._preferredAlgorithm = value; }
		}

		/// <summary>
		/// The preferred compression level
		/// </summary>
		public CompressionLevels CompressionLevel
		{
			get { return _compressionLevel; }
			set { this._compressionLevel = value; }
		}

		/// <summary>
		/// A list of content types to be exculded from processing
		/// </summary>
		public StringCollection ExcludeContentTypes
		{
			get { return this._excludeContentTypes; }
		}

		/// <summary>
		/// Gets a list of regular expression strings that  are 
		/// used to match user agents to be excluded from
		/// Http compression.
		/// </summary>
		public StringCollection ExcludeUserAgents
		{
			get { return this._excludeUserAgents; }
		}

		/// <summary>
		/// 
		/// </summary>
		public StringCollection TextContentTypes
		{
			get { return this._textContentTypes; }
		}

		/// <summary>
		/// 
		/// </summary>
		public StringCollection ExcludeRequestPath
		{
			get { return this._excludeRequestPath; }
		}

		/// <summary>
		/// Gets or sets a value specifying whether a user agent string
		/// must be sent to the server for the http compression
		/// to execute.
		/// </summary>
		public bool RequireUserAgent
		{
			get { return this._requireUserAgent; }
			set { this._requireUserAgent = value; }
		}

		internal ModuleSettings()
		{
			_preferredAlgorithm = CompressionTypes.Deflate;
			_compressionLevel = CompressionLevels.Normal;
			_excludeContentTypes = new StringCollection();
			_excludeUserAgents = new StringCollection();
			_excludeRequestPath = new StringCollection();
			_textContentTypes = new StringCollection();
			_requireUserAgent = false;

		}


		/// <summary>
		/// Get the current settings from the xml config file
		/// </summary>
		public static ModuleSettings GetSettings()
		{
			ModuleSettings settings = (ModuleSettings)ConfigurationManager.GetSection("Flesk.NET/HttpCompression");
			if (settings == null)
				return new ModuleSettings();
			else
				return settings;
		}




	}


	/// <summary>
	/// This class acts as a factory for the configuration settings. Pre .NET 2.0 goodness inside.
	/// </summary>
	internal class ConfigHandler : IConfigurationSectionHandler
	{

		/// <summary>
		/// Create a new config section handler.  This is of type <see cref="HttpCompressionModuleSettings"/>
		/// </summary>
		object IConfigurationSectionHandler.Create(object parent, object configContext, XmlNode node)
		{
			ModuleSettings ret = new ModuleSettings();

			if (node != null)
			{
				#region Parse Xml data

				IComparer cmp = CaseInsensitiveComparer.Default;

				XmlAttribute xaAlgorithm = node.Attributes["Algorithm"];
				if (xaAlgorithm != null)
				{
					if (cmp.Compare("gzip", xaAlgorithm.Value) == 0)
						ret.PreferredAlgorithm = CompressionTypes.GZip;
					else
						if (cmp.Compare("deflate", xaAlgorithm.Value) == 0)
							ret.PreferredAlgorithm = CompressionTypes.Deflate;
				}

				XmlAttribute xaCompressionLevel = node.Attributes["CompressionLevel"];
				if (xaCompressionLevel != null)
				{
					if (cmp.Compare("high", xaCompressionLevel.Value) == 0)
						ret.CompressionLevel = CompressionLevels.High;
					else
						if (cmp.Compare("low", xaCompressionLevel.Value) == 0)
							ret.CompressionLevel = CompressionLevels.Low;
						else
							ret.CompressionLevel = CompressionLevels.Normal;
				}

				XmlAttribute xaExcludedTypes = node.Attributes["ExcludeContentType"];
				if (xaExcludedTypes != null)
				{
					string strTypes = xaExcludedTypes.Value.ToLower();
					string[] types = strTypes.Split(';');
					foreach (string s in types)
						if (s.Length > 0)
							ret.ExcludeContentTypes.Add(s.Trim());

				}

				XmlNode xnExcludeUserAgent = node.SelectSingleNode("UserAgent");
				if (xnExcludeUserAgent != null)
				{
					XmlAttribute xaRequireUAString = xnExcludeUserAgent.Attributes["Required"];
					if (xaRequireUAString != null)
					{
						try
						{
							ret.RequireUserAgent = Convert.ToBoolean(xaRequireUAString.Value);
						}
						catch
						{
						}
					}

					XmlNodeList nlExcludeUA = xnExcludeUserAgent.SelectNodes("Exclude/@Match");
					if (nlExcludeUA.Count > 0)
					{
						foreach (XmlNode xnExcludeUA in nlExcludeUA)
						{
							string regex = xnExcludeUA.Value;
							if (regex != null && regex.Length > 0)
								ret.ExcludeUserAgents.Add(System.Web.HttpUtility.HtmlDecode(regex));
						}
					}
				}

				XmlNode xnContentType = node.SelectSingleNode("ContentType");
				if (xnContentType != null)
				{
					XmlNodeList nlTextType = xnContentType.SelectNodes("IsText/@Match");
					if (nlTextType.Count > 0)
					{
						foreach (XmlNode xnTextType in nlTextType)
						{
							string regex = xnTextType.Value;
							if (regex != null && regex.Length > 0)
								ret.TextContentTypes.Add(System.Web.HttpUtility.HtmlDecode(regex));
						}
					}
				}

				XmlNode xnRequestPath = node.SelectSingleNode("RequestPath");
				if (xnRequestPath != null)
				{
					XmlNodeList nlPath = xnRequestPath.SelectNodes("Exclude/@Match");
					if (nlPath.Count > 0)
					{
						foreach (XmlNode xnPath in nlPath)
						{
							string regex = xnPath.Value;
							if (regex != null && regex.Length > 0)
								ret.ExcludeRequestPath.Add(System.Web.HttpUtility.HtmlDecode(regex));
						}
					}
				}

				#endregion
			}

			return ret;
		}
	}


	/// <summary>
	/// The available types of compression to use with the HttpCompression module
	/// </summary>
	public enum CompressionTypes
	{
		Other = 0,
		/// <summary>
		/// Use a deprecated compression scheme
		/// </summary>
		Compress,
		/// <summary>
		/// Use the deflate algorithm
		/// </summary>
		Deflate,
		/// <summary>
		/// Use the gzip algorithm
		/// </summary>
		GZip,
		/// <summary>
		/// Use identity (no compression)
		/// </summary>
		Identity,
		/// <summary>
		/// Use any available method
		/// </summary>
		Any
	}


	/// <summary>
	/// The level of compression to use with some algorithms
	/// </summary>
	public enum CompressionLevels
	{
		/// <summary>
		/// Use a normal level of compression.  Compromises between speed and size
		/// </summary>
		Normal,
		/// <summary>
		/// Use a high level of compression.  Sacrifices speed for size.
		/// </summary>
		High,
		/// <summary>
		/// Use a low level of compression.  Sacrifices size for speed.
		/// </summary>
		Low
	}


	internal sealed class ContentEncodingInfo
	{
		static NumberFormatInfo nformat = GetNumberFormat();

		string name;

		public string Name
		{
			get { return name; }
			set { name = value; }
		}

		float preference;

		public float Preference
		{
			get { return preference; }
			set { preference = value; }
		}

		CompressionTypes type;

		public CompressionTypes CompressionType
		{
			get { return type; }
			set { type = value; }
		}


		internal void ParseQValue(string qstring)
		{
			float qvalue = 1F;
			if (!String.IsNullOrEmpty(qstring))
			{
				string[] qdef = qstring.Split('=');
				if (qdef.Length > 1)
				{
					float.TryParse(
						qdef[1],
						(
							NumberStyles.Number ^
							NumberStyles.AllowTrailingSign ^
							NumberStyles.AllowLeadingSign
						),
						nformat,
						out qvalue
						);
				}
			}

			this.preference = qvalue;
		}

		static NumberFormatInfo GetNumberFormat()
		{
			NumberFormatInfo ret = new NumberFormatInfo();
			ret.NumberDecimalSeparator = ".";
			return ret;
		}


	}

}
