/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * Copyright 2009, Flesk Telecom                                               *
 * This file is part of Flesk.NET Software.                                    *
 *                                                                             *
 * Flesk.NET Software is free software: you can redistribute it and/or modify  *
 * it under the terms of the GNU Lesser General Public License as published by *
 * the Free Software Foundation, either version 3 of the License, or           *
 * (at your option) any later version.                                         *
 *                                                                             *
 * Flesk.NET Software is distributed in the hope that it will be useful,       *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of              *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the               *
 * GNU General Public License for more details.                                *
 *                                                                             *
 * You should have received a copy of the GNU Lesser General Public License    *
 * along with Flesk.NET Software. If not, see <http://www.gnu.org/licenses/>.  *
 *                                                                             *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

using System;
using System.IO;

using ICSharpCode.SharpZipLib.Zip.Compression;
using ICSharpCode.SharpZipLib.Zip.Compression.Streams;

namespace Flesk.Accelerator.HttpCompression
{

	/// <summary>
	/// Provides <see cref="System.Web.HttpResponse"/> stream filtering with an deflate encoder.
	/// </summary>
	public sealed class DeflateEncoding : HttpContentEncoding 
	{

		private DeflaterOutputStream outDeflate = null;

		/// <summary>
		/// Returns "deflate".
		/// </summary>
		public override string Name 
		{
			get { return "deflate"; }
		}

		public override long Length
		{
			get
			{
				return outDeflate.Length;
			}
		}


		/// <summary>
		/// Creates a new <see cref="DeflateEncoding"/> instance.
		/// </summary>
		/// <param name="baseStream">Base stream.</param>
		public DeflateEncoding(Stream baseStream) : this(baseStream, CompressionLevels.Normal) { }

		/// <summary>
		/// Creates a new <see cref="DeflateEncoding"/> instance.
		/// </summary>
		/// <param name="baseStream">Base stream.</param>
		/// <param name="compressionLevel">Compression level.</param>
		public DeflateEncoding(Stream baseStream, CompressionLevels compressionLevel) : base(baseStream, compressionLevel) { }

		public override void Write(byte[] buffer, int offset, int count) 
		{
      
			if (outDeflate == null) 
			{
				Deflater deflater;
      
				switch(CompressionLevel)
				{
					case CompressionLevels.High:
						deflater = new Deflater(Deflater.BEST_COMPRESSION, true);
						break;
					case CompressionLevels.Low:
						deflater = new Deflater(Deflater.BEST_SPEED, true);
						break;
					case CompressionLevels.Normal:
					default:
						deflater = new Deflater(Deflater.DEFAULT_COMPRESSION, true);
						break;
				}
				outDeflate = new DeflaterOutputStream(BaseStream, deflater, 1024);
			}
			outDeflate.Write(buffer, offset, count);
		}


		public override void Close() 
		{
			if (outDeflate != null)
				outDeflate.Finish();
			base.Close();
		}


	}
}
