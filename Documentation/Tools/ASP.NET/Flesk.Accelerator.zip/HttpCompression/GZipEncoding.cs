/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * Copyright 2009, Flesk Telecom                                               *
 * This file is part of Flesk.NET Software.                                    *
 *                                                                             *
 * Flesk.NET Software is free software: you can redistribute it and/or modify  *
 * it under the terms of the GNU Lesser General Public License as published by *
 * the Free Software Foundation, either version 3 of the License, or           *
 * (at your option) any later version.                                         *
 *                                                                             *
 * Flesk.NET Software is distributed in the hope that it will be useful,       *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of              *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the               *
 * GNU General Public License for more details.                                *
 *                                                                             *
 * You should have received a copy of the GNU Lesser General Public License    *
 * along with Flesk.NET Software. If not, see <http://www.gnu.org/licenses/>.  *
 *                                                                             *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

using System;
using System.IO;

using System.Text;
using System.Diagnostics;

using ICSharpCode.SharpZipLib.Zip.Compression;
using ICSharpCode.SharpZipLib.GZip;
using ICSharpCode.SharpZipLib.Zip.Compression.Streams;

namespace Flesk.Accelerator.HttpCompression
{

	/// <summary>
	/// Provides <see cref="System.Web.HttpResponse"/> stream filtering with a gzip encoder.
	/// </summary>
	public sealed class GZipEncoding : HttpContentEncoding 
	{

		private GZipOutputStream outGZip = null;


		/// <summary>
		/// Returns "gzip".
		/// </summary>
		/// <value></value>
		public override string Name 
		{
			get { return "gzip"; }
		}

		public override long Length
		{
			get { return outGZip.Length; }
		}


		public GZipEncoding(Stream baseStream) : base(baseStream, CompressionLevels.Normal) { }

		public override void Write(byte[] buffer, int offset, int count) 
		{
			if (outGZip == null)
				outGZip = new GZipOutputStream(BaseStream, 1024);
			outGZip.Write(buffer, offset, count);
		}

		public override void Close() 
		{
			if (outGZip != null)
				outGZip.Finish();
			base.Close();
		}

	}
}
