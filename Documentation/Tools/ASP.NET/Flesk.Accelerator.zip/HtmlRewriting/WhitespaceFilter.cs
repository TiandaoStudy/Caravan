/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * Copyright 2009, Flesk Telecom                                               *
 * This file is part of Flesk.NET Software.                                    *
 *                                                                             *
 * Flesk.NET Software is free software: you can redistribute it and/or modify  *
 * it under the terms of the GNU Lesser General Public License as published by *
 * the Free Software Foundation, either version 3 of the License, or           *
 * (at your option) any later version.                                         *
 *                                                                             *
 * Flesk.NET Software is distributed in the hope that it will be useful,       *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of              *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the               *
 * GNU General Public License for more details.                                *
 *                                                                             *
 * You should have received a copy of the GNU Lesser General Public License    *
 * along with Flesk.NET Software. If not, see <http://www.gnu.org/licenses/>.  *
 *                                                                             *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

using System;
using System.IO;
using System.Collections;

namespace Flesk.Accelerator.HtmlRewriting
{
	/// <summary>
	/// Collapses multiple whitespace characters.
	/// Uses crappy algorithm, and may break javascript code. Avoid.
	/// </summary>
	public class WhitespaceFilter : HtmlFilter
	{
		byte whitespaceCharWritten = byte.MinValue;
		WhitespaceCollapseMode mode;

		/// <summary>
		/// Gets or sets the substitution mode. If set to Aggressive, all whitespace characters will collapse into the first.
		/// </summary>
		public WhitespaceCollapseMode CollapseMode
		{
			get { return this.mode; }
			set { this.mode = value; }
		}


		public WhitespaceFilter(Stream baseStream) : base(baseStream)
		{
		}

		public WhitespaceFilter(Stream baseStream, WhitespaceCollapseMode mode) : this(baseStream)
		{
			this.mode = mode;
		}

		public override void Write(byte[] buffer, int offset, int count)
		{
			ArrayList temp = new ArrayList();

			int i = offset - 1;
			int max = offset + count;
			while (++i < max)
			{
				if (IsWhitespaceChar(buffer[i]))
				{
					byte subst = byte.MaxValue;
					switch (this.mode)
					{
						case WhitespaceCollapseMode.Conservative:
							subst = buffer[i];
							break;
					}

					if (this.whitespaceCharWritten != subst)
					{
						temp.Add(buffer[i]);
						this.whitespaceCharWritten = subst;
					}
				}
				else
				{
					temp.Add(buffer[i]);
					this.whitespaceCharWritten = byte.MinValue;
				}
			}

			this.BaseStream.Write((byte[])temp.ToArray(typeof(byte)), 0, temp.Count);
		}


		static bool IsWhitespaceChar(byte b)
		{
			return (
				(b ^ 0x20) == 0 ||
				(b ^ 0x0A) == 0 ||
				(b ^ 0x0D) == 0 ||
				(b ^ 0x09) == 0
				);
		}

	}


	public enum WhitespaceCollapseMode
	{
		Conservative,
		Aggressive
	}

}
