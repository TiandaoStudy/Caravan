/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * Copyright 2009, Flesk Telecom                                               *
 * This file is part of Flesk.NET Software.                                    *
 *                                                                             *
 * Flesk.NET Software is free software: you can redistribute it and/or modify  *
 * it under the terms of the GNU Lesser General Public License as published by *
 * the Free Software Foundation, either version 3 of the License, or           *
 * (at your option) any later version.                                         *
 *                                                                             *
 * Flesk.NET Software is distributed in the hope that it will be useful,       *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of              *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the               *
 * GNU General Public License for more details.                                *
 *                                                                             *
 * You should have received a copy of the GNU Lesser General Public License    *
 * along with Flesk.NET Software. If not, see <http://www.gnu.org/licenses/>.  *
 *                                                                             *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

using System;
using System.IO;

namespace Flesk.Accelerator.HtmlRewriting
{
	/// <summary>
	/// Summary description for HtmlFilter.
	/// </summary>
	public abstract class HtmlFilter : Stream
	{
		Stream _baseStream;

		protected Stream BaseStream
		{
			get { return this._baseStream; }
		}

		public HtmlFilter(Stream baseStream)
		{
			this._baseStream = baseStream;
		}



		public override bool CanRead 
		{
			get { return false; }
		}

		public override bool CanSeek 
		{
			get { return false; }
		}

		public override bool CanWrite 
		{
			get { return this._baseStream.CanWrite; }
		}

		public override long Length 
		{
			get { throw new NotSupportedException(); }
		}

		public override long Position 
		{
			get { throw new NotSupportedException(); }
			set { throw new NotSupportedException(); }
		}

		public override void SetLength(long length) 
		{
			throw new NotSupportedException();
		}

		public override long Seek(long offset, System.IO.SeekOrigin direction) 
		{
			throw new NotSupportedException();
		}

		public override void Close() 
		{
			this._baseStream.Close();
		}

		public override void Flush() 
		{
			this._baseStream.Flush();
		}

		public override int Read(byte[] buffer, int offset, int count) 
		{
			throw new NotSupportedException();
		}
	}

}
