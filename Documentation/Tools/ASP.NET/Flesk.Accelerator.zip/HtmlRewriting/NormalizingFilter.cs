/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * Copyright 2009, Flesk Telecom                                               *
 * This file is part of Flesk.NET Software.                                    *
 *                                                                             *
 * Flesk.NET Software is free software: you can redistribute it and/or modify  *
 * it under the terms of the GNU Lesser General Public License as published by *
 * the Free Software Foundation, either version 3 of the License, or           *
 * (at your option) any later version.                                         *
 *                                                                             *
 * Flesk.NET Software is distributed in the hope that it will be useful,       *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of              *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the               *
 * GNU General Public License for more details.                                *
 *                                                                             *
 * You should have received a copy of the GNU Lesser General Public License    *
 * along with Flesk.NET Software. If not, see <http://www.gnu.org/licenses/>.  *
 *                                                                             *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

using System;
using System.IO;

namespace Flesk.Accelerator.HtmlRewriting
{
	/// <summary>
	/// Uses crappy algorithm. Avoid.
	/// </summary>
	public class NormalizingFilter : HtmlFilter
	{
		bool isInsideTag = false;
		bool isAttributeValue = false;

		CaseNormalization toCase = CaseNormalization.None;

		public CaseNormalization NormalizationCase
		{
			get { return this.toCase; }
			set { this.toCase = value; }
		}


		public NormalizingFilter(Stream baseStream) : base(baseStream)
		{
		}

		public NormalizingFilter(Stream baseStream, CaseNormalization normalization) : this(baseStream)
		{
			this.toCase = normalization;
		}
		

		public override void Write(byte[] buffer, int offset, int count)
		{
			if (this.toCase != CaseNormalization.None)
			{

				int i = offset - 1;
				int max = offset + count;
				while (++i < max)
				{
				
					if ((buffer[i] ^ 0x3C) == 0) //'<'
					{
						this.isInsideTag = true;
						continue;
					}

					if (this.isInsideTag)
					{
						if (
							(buffer[i] ^ 0x21) == 0 ||
							(buffer[i] ^ 0x3E) == 0
							)
							// '!', '>'
						{
							this.isInsideTag = false;
							continue;
						}

						if ((buffer[i] ^ 0x3D) == 0) // '='
						{
							this.isAttributeValue = true;
							i++; // skip next char
							continue;
						}

						if (this.isAttributeValue)
						{
							if (
								char.IsWhiteSpace(Convert.ToChar(buffer[i])) ||
								(buffer[i] ^ 0x22) == 0 ||  // '"'
								(buffer[i] ^ 0x27) == 0		// '''
								)
							{
								this.isAttributeValue = false;
								continue;
							}
						}

						if (!this.isAttributeValue)
						{
							char c = Convert.ToChar(buffer[i]);
							if (char.IsLetter(c))
							{
								if (this.toCase == CaseNormalization.Lowercase)
									buffer[i] |= 0x20; // lowercase
								else
									buffer[i] &= 0xDF; // uppercase
							}
						}



					}
				
				}

			}

			this.BaseStream.Write(buffer, offset, count);

		}

		static bool IsLetter(byte b)
		{
			b |= 0x20;
			return (b>=0x61 && b<=0x7A);
		}

	}


	public enum CaseNormalization
	{
		None = 0,
		Lowercase = 1,
		Uppercase = 2
	}

}
