/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * Copyright 2009, Flesk Telecom                                               *
 * This file is part of Flesk.NET Software.                                    *
 *                                                                             *
 * Flesk.NET Software is free software: you can redistribute it and/or modify  *
 * it under the terms of the GNU Lesser General Public License as published by *
 * the Free Software Foundation, either version 3 of the License, or           *
 * (at your option) any later version.                                         *
 *                                                                             *
 * Flesk.NET Software is distributed in the hope that it will be useful,       *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of              *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the               *
 * GNU General Public License for more details.                                *
 *                                                                             *
 * You should have received a copy of the GNU Lesser General Public License    *
 * along with Flesk.NET Software. If not, see <http://www.gnu.org/licenses/>.  *
 *                                                                             *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

using System;
using System.Collections;
using System.Configuration;
using System.Xml;

namespace Flesk.Accelerator.HtmlRewriting
{
	/// <summary>
	/// Represents the configuration details of the HtmlRewriting for the current application.
	/// </summary>
	internal class ModuleSettings
	{
		private CaseNormalization _tagNormalization;
		private WhitespaceCollapseMode _collapseMode;
		private bool _enableWhitespaceFilter;


		/// <summary>
		/// Whether the Whitespace filter is running
		/// </summary>
		public bool EnableWhitespaceFilter
		{
			get { return this._enableWhitespaceFilter; }
			set { this._enableWhitespaceFilter = value; }
		}

		public WhitespaceCollapseMode WhitespaceCollapseMode
		{
			get { return this._collapseMode; }
			set { this._collapseMode = value; }
		}


		/// <summary>
		/// The tag normalization setting
		/// </summary>
		public CaseNormalization TagNormalization
		{
			get { return this._tagNormalization; }
			set { this._tagNormalization = value; }
		}


		internal ModuleSettings()
		{
			this._tagNormalization = CaseNormalization.None;
			this._enableWhitespaceFilter = false;
			this._collapseMode = WhitespaceCollapseMode.Conservative;
		}


		/// <summary>
		/// Get the current settings from the xml config file
		/// </summary>
		public static ModuleSettings GetSettings()
		{
			ModuleSettings settings = (ModuleSettings)ConfigurationManager.GetSection("Flesk.NET/HtmlRewriting");
			if (settings == null)
				return new ModuleSettings();
			else
				return settings;
		}




	}


	/// <summary>
	/// This class acts as a factory for the configuration settings. Pre .NET 2.0 goodness inside.
	/// </summary>
	internal class ConfigHandler : IConfigurationSectionHandler
	{

		/// <summary>
		/// Create a new config section handler.  This is of type <see cref="HtmlRewriting.ModuleSettings"/>
		/// </summary>
		object IConfigurationSectionHandler.Create(object parent, object configContext, XmlNode node)
		{
			bool enableWhitespaceFilter = false;
			WhitespaceCollapseMode collapseMode = WhitespaceCollapseMode.Conservative;
			CaseNormalization tagNormalization = CaseNormalization.None;

			if (node != null)
			{
				#region Parse Xml data

				IComparer cmp = CaseInsensitiveComparer.Default;

				XmlAttribute xaEnableWSFilter = node.Attributes["EnableWhitespaceFilter"];
				if (xaEnableWSFilter != null)
				{
					string val = xaEnableWSFilter.Value;
					try
					{
						if (val == "1")
							enableWhitespaceFilter = true;
						else
							enableWhitespaceFilter = Convert.ToBoolean(val);
					}
					catch
					{
					}

				}

				XmlAttribute xaCollapseMode = node.Attributes["WhitespaceCollapseMode"];
				if (xaCollapseMode != null)
				{
					string val = xaCollapseMode.Value;
					try
					{
						if (string.Compare(val, "Aggressive") == 0)
							collapseMode = WhitespaceCollapseMode.Aggressive;
						else
							collapseMode = WhitespaceCollapseMode.Conservative;
					}
					catch
					{
					}

				}


				XmlAttribute xaTagNormalization = node.Attributes["TagNormalization"];
				if (xaTagNormalization != null)
				{
					string norm = xaTagNormalization.Value;
					if (String.Compare(norm, "UPPERCASE", true) == 0)
						tagNormalization = CaseNormalization.Uppercase;
					else
						if (String.Compare(norm, "lowercase", true) == 0)
							tagNormalization = CaseNormalization.Lowercase;
				}

				#endregion
			}

			ModuleSettings ret = new ModuleSettings();
			ret.EnableWhitespaceFilter = enableWhitespaceFilter;
			ret.TagNormalization = tagNormalization;
			ret.WhitespaceCollapseMode = collapseMode;


			return ret;
		}
	}


}
