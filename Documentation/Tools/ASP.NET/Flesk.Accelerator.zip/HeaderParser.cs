/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * Copyright 2009, Flesk Telecom                                               *
 * This file is part of Flesk.NET Software.                                    *
 *                                                                             *
 * Flesk.NET Software is free software: you can redistribute it and/or modify  *
 * it under the terms of the GNU Lesser General Public License as published by *
 * the Free Software Foundation, either version 3 of the License, or           *
 * (at your option) any later version.                                         *
 *                                                                             *
 * Flesk.NET Software is distributed in the hope that it will be useful,       *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of              *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the               *
 * GNU General Public License for more details.                                *
 *                                                                             *
 * You should have received a copy of the GNU Lesser General Public License    *
 * along with Flesk.NET Software. If not, see <http://www.gnu.org/licenses/>.  *
 *                                                                             *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;

namespace Flesk.Accelerator
{
	/// <summary>
	/// Holds name=value info
	/// </summary>
	internal sealed class Token
	{
		string name;
		public string Name
		{
			get { return name; }
			set { name = value; }
		}

		int position;
		public int Position
		{
			get { return this.position; }
			set { this.position = value; }
		}

		string val;
		public string Value
		{
			get { return val; }
			set { val = value; }
		}


		public Token()
		{
		}

	}

	internal sealed class Tokenizer : IEnumerable
	{
		string text;
		string[] items;

		public string Text
		{
			get { return this.text; }
			set { this.text = value; }
		}


		Tokenizer()
		{
		}

		public Tokenizer(string input)
		{
			if (!String.IsNullOrEmpty(input))
			{
				this.text = input;
				this.items = this.text.Split(',');
			}
		}


		#region IEnumerable Members

		public IEnumerator GetEnumerator()
		{
			for (int index = 0; index < this.items.Length; index++)
			{
				string input = this.items[index];

				Token ret = this.ParseToken(input);
				if (ret != null)
					ret.Position = index + 1;

				yield return ret;
			}
		}

		#endregion


		Token ParseToken(string input)
		{
			Token ret = null;
			if (!String.IsNullOrEmpty(input))
			{
				string[] cc = input.Split(';');
				if (cc.Length > 0)
				{
					ret = new Token();
					ret.Name = cc[0].Trim();

					if (cc.Length > 1)
					{
						ret.Value = cc[1].Trim();
					}

				}
			}
			return ret;
		}

	}

	/// <summary>
	/// Contains a list of functions that will execute
	/// upon each Token instance provided by a Tokenizer.
	/// The list is accessible by a MulticastDelegate event.
	/// If a given function evaluates to True, 
	/// it is removed from the list.
	/// </summary>
	internal sealed class TokenParser : IDisposable
	{
		List<Predicate<Token>> handlers;
		Tokenizer tok;
		bool ignoreEmptyTokens = true;

		public event Predicate<Token> Evaluate;

		public Tokenizer Tokenizer
		{
			get { return this.tok; }
			set { this.tok = value; }
		}

		public bool IgnoreEmptyTokens
		{
			get { return this.ignoreEmptyTokens; }
			set { this.ignoreEmptyTokens = value; }
		}


		public TokenParser()
		{
		}


		public void Parse()
		{
			this.handlers = new List<Predicate<Token>>();
			foreach (Predicate<Token> evalFunction in this.Evaluate.GetInvocationList())
				this.handlers.Add(evalFunction);

			foreach (Token t in this.tok)
			{
				if (t == null && this.ignoreEmptyTokens)
					continue;
				this.EvaluateToken(t);
			}

		}

		/// <summary>
		/// Invoke the Token Evaluate handlers until
		/// one returns true. Then, remove that handler
		/// from the invocation list, and break the cycle.
		/// </summary>
		/// <remarks>
		/// The WCS happens when the tokens are found in
		/// the reverse order of the invocation list. It then
		/// has to cycle through the last one and remove it,
		/// wich is inconsequent.
		/// </remarks>
		/// <param name="token">Token.</param>
		void EvaluateToken(Token token)
		{
			int i = -1;
			while (++i < handlers.Count)
			{
				Predicate<Token> handler = handlers[i];
				if (handler != null)
				{
					bool evaluated = handler(token);
					if (evaluated)
					{
						//remove from invocation list and break;
						handlers.RemoveAt(i);
						break;
					}
				}
			}

		}

		#region IDisposable Members

		void IDisposable.Dispose()
		{
			if (this.handlers != null)
			{
				this.handlers.Clear();
				this.handlers = null;
			}

			if (this.tok != null)
				this.tok = null;
		}

		#endregion

	}


}
